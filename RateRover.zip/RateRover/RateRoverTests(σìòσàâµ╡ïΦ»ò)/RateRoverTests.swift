//
//  RateRoverTests.swift
//  RateRoverTests
//
//  Created by Molly on 2025/11/25.
//

import Testing
@testable import RateRover

struct RateRoverTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
