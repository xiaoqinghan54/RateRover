//
//  Currency.swift
//  RateRover
//  职责：定义应用的核心数据模型，与 API 响应的数据结构保持一致。
//
//

import Foundation

/// 货币类型，用于区分法币和加密货币
enum CurrencyType: String, Codable {
    case fiat
    case crypto
}

/// 符合 PRD 规范的货币数据模型
/// Codable: 使其能轻松地从 JSON 数据解码或编码。
/// Identifiable: 使其可以直接在 SwiftUI 的 ForEach 中使用，`code` 作为唯一标识符。
struct Currency: Codable, Identifiable {
    var id: String { code } // 将 code 属性用作唯一 ID
    
    let code: String
    let name: String
    let rateToUsd: Double
    let displayPrecision: Int
    let type: CurrencyType
    
    // CodingKeys 用于将 JSON 中的 snake_case 字段名映射到 Swift 的 camelCase 属性名。
    enum CodingKeys: String, CodingKey {
        case code, name, type
        case rateToUsd = "rate_to_usd"
        case displayPrecision = "display_precision"
    }
    
    // 计算属性：根据货币代码返回一个临时的 SF Symbol 图标名
    var iconName: String {
        switch code {
        case "USD": return "dollarsign.circle.fill"
        case "CNY": return "yensign.circle.fill"
        case "BTC": return "bitcoinsign.circle.fill"
        default: return "questionmark.circle.fill"
        }
    }
}
