//
//  ChartsViewModel.swift
//  RateRover
//  职责：作为 ChartsView 的“大脑”，处理图表数据、货币对选择和时间周期切换的逻辑。
//
//

import SwiftUI

/// 定义图表的时间周期
enum TimePeriod: String, CaseIterable {
    case D1 = "1D"
    case W1 = "1W"
    case M1 = "1M"
    case M3 = "3M"
    case Y1 = "1Y"
    case ALL = "All"
}

/// 定义单个图表数据点
struct ChartDataPoint: Identifiable {
    let id = UUID()
    let date: Date
    let value: Double
}

@MainActor
class ChartsViewModel: ObservableObject {
    
    // MARK: - Published Properties
    
    @Published var chartData: [ChartDataPoint] = []
    @Published var selectedPeriod: TimePeriod = .M1
    @Published var percentageChange: Double = 0.0
    
    // 货币对选择的模拟状态
    @Published var baseCurrencyCode: String = "USD"
    @Published var quoteCurrencyCode: String = "CNY"
    
    // MARK: - Initializer
    
    init() {
        loadChartData()
    }
    
    // MARK: - Public Methods
    
    /// 切换时间周期
    func selectPeriod(_ period: TimePeriod) {
        selectedPeriod = period
        loadChartData() // 重新加载对应周期的数据
    }
    
    /// 交换货币对
    func swapCurrencies() {
        let temp = baseCurrencyCode
        baseCurrencyCode = quoteCurrencyCode
        quoteCurrencyCode = temp
        loadChartData() // 货币对变化，重新加载数据
    }
    
    // MARK: - Private Helper Methods
    
    /// **模拟**加载图表数据
    private func loadChartData() {
        // 1. 生成模拟数据点
        var dataPoints: [ChartDataPoint] = []
        var currentValue = Double.random(in: 6.8...7.3)
        
        for i in 0..<30 { // 模拟一个月的数据
            let date = Calendar.current.date(byAdding: .day, value: -i, to: Date())!
            currentValue += Double.random(in: -0.05...0.05)
            dataPoints.insert(ChartDataPoint(date: date, value: currentValue), at: 0)
        }
        self.chartData = dataPoints
        
        // 2. 计算模拟的涨跌幅
        let startValue = chartData.first?.value ?? 0
        let endValue = chartData.last?.value ?? 0
        self.percentageChange = (endValue - startValue) / startValue
    }
}
