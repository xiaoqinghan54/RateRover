//  CurrencySelectionView.swift
//  RateRover
//
//  职责：提供一个可复用的货币选择列表界面。
//
import SwiftUI

struct CurrencySelectionView: View {
    // 从外部传入所有可选的货币
    let currencies: [Currency]
    // 使用闭包将用户的选择传递出去
    let onSelect: (String) -> Void
    // 用于关闭当前视图
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            List(currencies) { currency in
                Button(action: {
                    onSelect(currency.code) // 调用闭包，传递选中的货币代码
                    dismiss() // 关闭视图
                }) {
                    HStack {
                        Text(currency.code)
                            .font(.headline)
                            .frame(width: 60, alignment: .leading)
                        Text(currency.name)
                            .font(.body)
                        Spacer()
                    }
                    .foregroundColor(.primary) // 确保文本颜色在所有模式下都正确
                }
                .listRowInsets(EdgeInsets(top: 15, leading: 20, bottom: 15, trailing: 20)) // 为每行添加内边距
            }
            .listStyle(.plain) // 使用 .plain 样式以移除默认的分组样式和边距
            .navigationTitle("选择货币")
            .navigationBarItems(trailing: Button("Cancel") {
                dismiss()
            })
        }
    }
}
