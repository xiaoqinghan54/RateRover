//
//  HistoricalChartViewModel.swift
//  RateRover
//  职责：作为 HistoricalChartView 的“大脑”，处理货币对选择、时间范围和图表数据的逻辑。
//

import Foundation

@MainActor
class HistoricalChartViewModel: ObservableObject {
    
    // MARK: - Published Properties
    @Published private(set) var fromCurrencyCode = "USD"
    @Published private(set) var toCurrencyCode = "CNY"
    @Published private(set) var allCurrencies: [Currency] = []
    
    // 新增：用于控制时间范围的状态
    @Published var selectedTimeRange: TimeRange = .oneMonth
    
    @Published private(set) var chartData: [HistoricalDataPoint] = []
    @Published private(set) var isLoading = false
    @Published var errorMessage: String? // 新增：用于向视图报告错误
    
    // MARK: - Private State
    private let apiService: APIServiceProtocol

    // MARK: - Initializer
    init(apiService: APIServiceProtocol = APIService()) {
        self.apiService = apiService
        
        Task {
            await loadInitialData()
        }
        
        // 订阅 selectedTimeRange 的变化，当它改变时自动重新加载图表
        $selectedTimeRange
            .dropFirst() // 忽略初始值
            .sink { [weak self] _ in
                self?.reloadChartData()
        }
    }
    
    // MARK: - Public Interface
    
    /// 视图调用的入口，用于更改货币
    func changeCurrency(to newCode: String, for side: ConversionSide) {
        // 确保新选择的货币存在，并且与另一侧的货币不同
        guard allCurrencies.contains(where: { $0.code == newCode }),
              (side == .from && newCode != toCurrencyCode) || (side == .to && newCode != fromCurrencyCode)
        else { return }
        
        switch side {
        case .from:
            fromCurrencyCode = newCode
        case .to:
            toCurrencyCode = newCode
        }
        
        // 更改货币后，重新加载图表数据
        reloadChartData()
    }
    
    // MARK: - Private Logic
    
    private func loadInitialData() async {
        isLoading = true
        errorMessage = nil
        
        async let currenciesTask = apiService.fetchLatestRates(base: "USD")
        async let chartDataTask = apiService.fetchHistoricalRates(from: fromCurrencyCode, to: toCurrencyCode, range: selectedTimeRange)
        
        do {
            self.allCurrencies = try await currenciesTask
            self.chartData = try await chartDataTask
        } catch {
            // 新增：设置用户友好的错误信息
            errorMessage = "无法加载图表数据，请检查您的网络连接。"
            print("Error loading initial chart data: \(error.localizedDescription)")
        }
        
        isLoading = false
    }
    
    private func reloadChartData() {
        Task {
            isLoading = true
            errorMessage = nil
            do {
                chartData = try await apiService.fetchHistoricalRates(from: fromCurrencyCode, to: toCurrencyCode, range: selectedTimeRange)
            } catch {
                errorMessage = "无法加载图表数据，请检查您的网络连接。"
                print("Error reloading chart data: \(error.localizedDescription)")
                chartData = [] // 出错时清空数据
            }
            isLoading = false
        }
    }
}
