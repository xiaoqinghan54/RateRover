//
//  CalculatorPadView.swift
//  RateRover
//
//  职责：提供一个用于上下文计算的、可复用的计算器键盘。
//

import SwiftUI

struct CalculatorPadView: View {
    
    @Binding var calculationString: String
    let onButtonTap: (String) -> Void
    
    // 新增：允许从外部传入操作符按钮的颜色
    var operatorColor: Color = .accentColor
    
    private let buttons: [[String]] = [
        ["AC", "⌫", "%", "÷"],
        ["7", "8", "9", "×"],
        ["4", "5", "6", "-"],
        ["1", "2", "3", "+"],
        ["0", ".", "="],
        ["Done"] // 新增：为弹窗模式增加“完成”按钮
    ]
    
    var body: some View {
        // 改造：使用 GeometryReader 实现自适应布局
        GeometryReader { geometry in
            // =================================================================
            // MARK: - 布局参数调节区 (Layout Parameters)
            // =================================================================
            let horizontalPadding: CGFloat = 12 // 整个键盘的左右外边距
            let verticalPadding: CGFloat = 12   // 整个键盘的上下外边距
            let buttonSpacing: CGFloat = 12     // 按钮之间的间距
            // =================================================================

            // --- 修复：动态计算按钮尺寸，改为基于高度 ---
            let totalVerticalSpacing = CGFloat(buttons.count - 1) * buttonSpacing
            let availableHeight = geometry.size.height - (2 * verticalPadding) - totalVerticalSpacing
            // 我们有 6 行按钮（5行数字+1行Done），所以除以 6
            let buttonDimension = max(0, availableHeight / CGFloat(buttons.count))
            // -------------------------

            VStack(spacing: buttonSpacing) {
                // 按钮网格
                ForEach(buttons, id: \.self) { row in
                    HStack(spacing: buttonSpacing) {
                        ForEach(row, id: \.self) { symbol in
                            // “Done”按钮特殊处理，让它横跨整行
                            if symbol == "Done" {
                                Button(action: { onButtonTap(symbol) }) {
                                    Text(symbol).font(.headline.weight(.semibold))
                                }
                                .frame(maxWidth: .infinity)
                                .frame(height: buttonDimension)
                                .background(operatorColor)
                                .foregroundColor(.white)
                                .cornerRadius(buttonDimension / 2)
                                continue // 跳过后续的常规按钮处理
                            }
                            
                            Button(action: { onButtonTap(symbol) }) {
                                // 改造：根据符号显示文本或图标
                                if symbol == "⌫" {
                                    Image(systemName: "delete.left")
                                        .font(.title)
                                } else {
                                    Text(symbol)
                                        .font(.title)
                                }
                            }
                            // 高亮：按钮尺寸现在是动态计算的
                            .frame(width: calculateButtonWidth(for: symbol, in: geometry.size, buttonDimension: buttonDimension, spacing: buttonSpacing), height: buttonDimension)
                            .background(buttonColor(for: symbol))
                            .foregroundColor(buttonForegroundColor(for: symbol))
                            .cornerRadius(12)
                        }
                    }
                }
            }
            .padding(.horizontal, horizontalPadding)
            .padding(.vertical, verticalPadding)
        }
    }
    
    // MARK: - Helper Functions for Styling
    
    // 新增：一个辅助方法，用于计算不同按钮的宽度
    private func calculateButtonWidth(for symbol: String, in size: CGSize, buttonDimension: CGFloat, spacing: CGFloat) -> CGFloat {
        if symbol == "0" {
            // 尝试让 "0" 按钮占据两个标准按钮的宽度
            let standardButtonWidth = (size.width - (2 * 12) - (3 * 12)) / 4
            return standardButtonWidth * 2 + spacing
        }
        return buttonDimension
    }
    
    private func buttonColor(for symbol: String) -> Color {
        switch symbol {
        case "÷", "×", "-", "+", "=":
            return operatorColor // 改造：使用可配置的颜色
        case "AC", "⌫", "%": // 改造：将 "±" 的样式应用到 "⌫"
            return Color(uiColor: .systemGray4) // 改造：功能键使用更浅的灰色
        default:
            return Color(uiColor: .systemGray6) // 改造：数字键使用最浅的灰色
        }
    }
    
    private func buttonForegroundColor(for symbol: String) -> Color {
        switch symbol {
        case "÷", "×", "-", "+", "=":
            return .white
        default:
            return .primary // 改造：其他按钮文字颜色自适应
        }
    }
}

struct CalculatorPadView_Previews: PreviewProvider {
    static var previews: some View {
        // 修复：为预览代码补全 operatorColor 参数，以消除歧义
        CalculatorPadView(calculationString: .constant("100+50"), onButtonTap: { _ in }, operatorColor: .orange)
            .padding()
    }
}