//
//  RateRoverApp.swift
//  RateRover
//
//  Created by Molly on 2025/11/25.
//

import SwiftUI

@main
struct RateRoverApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
